Config.DiscordLogs = {
    Webhooks = {
        default = '',
        test = '',
        Chat = '',
        UserActions = '',
        Resources = '',
        Paycheck = ''
    },

    Colors = { -- https://www.spycolor.com/
        default = 14423100,
        blue = 255,
        red = 16711680,
        green = 65280,
        white = 16777215,
        black = 0,
        orange = 16744192,
        yellow = 16776960,
        pink = 16761035,
        lightgreen = 65309
    }
}
